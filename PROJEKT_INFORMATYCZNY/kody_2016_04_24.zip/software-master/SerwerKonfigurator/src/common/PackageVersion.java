package common;
public class PackageVersion {
	public static final long serialVersionUID = 1L; 
}
